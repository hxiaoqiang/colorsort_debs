#!/bin/sh

#设置静态地址 192.168.211.x 其中x为板号,删掉重新创建

connection=`echo taiho | sudo -S nmcli connection|grep static`
if [ -n "${connection}" ]; then
    echo "connection static has been created"

    echo taiho | sudo -S sudo nmcli connection delete static
    echo taiho | sudo -S nmcli connection add con-name static ifname eth0 type ethernet ipv4.method manual ipv4.addresses 192.168.211.${1}/24 ipv4.gateway 192.168.211.1 ipv4.dns 192.168.211.1
    echo taiho | sudo -S nmcli connection up static ifname eth0
else
    echo "don't have connection static,create it"
    echo taiho | sudo -S nmcli connection add con-name static ifname eth0 type ethernet ipv4.method manual ipv4.addresses 192.168.211.${1}/24 ipv4.gateway 192.168.211.1 ipv4.dns 192.168.211.1
    echo taiho | sudo -S nmcli connection up static ifname eth0
fi

