#!/bin/sh

#测试升级内核 设备树 应用程序 AI程序 AI库
BOOT=linux-u-boot-vim3r-vendor_1.0.7-2015.01_arm64.deb
KERNEL=linux-image-amlogic-4.9_1.0.7_arm64.deb
DEVICETREE=linux-dtb-amlogic-4.9_1.0.7_arm64.deb
APP=taiho-colorsort_1.0.7_arm64.deb
AI_APP=AI_DETECTOR-1.0.3-Linux.deb
FPGA=SGA_AIC_V10.bin
DIR=/tmp/files

## Print information message
## $1 - message
info_msg() {
        echo "$1"
}

checkfile()
{
        time=$(date "+%Y-%m-%d %H:%M:%S")   #获取当前系统时间
        filename=/tmp/update.zip
        if [ ! -f "$filename" ]
        then
            info_msg "/tmp/update.zip don't exsit"
            exit 1
        fi
        #filesize='ls -l $filename | awk '{ printf $5}''          #获取文件本身大小
        filesize=$(wc -c <"$filename")
        maxsize=$((1024*10))                                        #最大内存10k
        if [ $filesize -gt $maxsize ]                                   #判断文件是否大于某个内存大小，
        then
            info_msg "filesize:$filesize"
            update_file
        else
           info_msg "error: filesize:$filesize"
           exit 2
        fi
}

update_file()
{
    flash_count=0
    mkdir -p $DIR
    unzip /tmp/update.zip -d /tmp/files

    status=$?
    if [ "$status" -ne 0 ]; then
        info_msg "not a zip file; $status"
        exit $status
    fi

    for file in /tmp/files/*; do
        echo "$(basename "$file")"
    done

    if [ ! -f "$DIR/$BOOT" ]
    then
        info_msg "file:$DIR/$BOOT don't exsit"
    else
        echo taiho | sudo -S dpkg -i $DIR/$BOOT
        status=$?
        if [ "$status" -ne 0 ]; then
            info_msg "dkpg -i $BOOT FAIL"
            exit $status
        fi
        flash_count=$(($flash_count+1))

        info_msg "dkpg -i  $DIR/$BOOT fail"
    fi

    if [ ! -f "$DIR/$KERNEL" ]
    then
        info_msg "file:$DIR/$KERNEL don't exsit"
    else
        echo taiho | sudo -S dpkg -i $DIR/$KERNEL
        status=$?
        if [ "$status" -ne 0 ]; then
            info_msg "dkpg -i $KERNEL FAIL"
            exit $status
        fi
        flash_count=$(($flash_count+1))
        info_msg "dkpg -i  $DIR/$KERNEL"
    fi

    if [ ! -f "$DIR/$DEVICETREE" ]
    then
        info_msg "file:$DIR/$DEVICETREE don't exsit"
    else
        echo taiho | sudo -S dpkg -i $DIR/$DEVICETREE
        status=$?
        if [ "$status" -ne 0 ]; then
            info_msg "dkpg -i $DEVICETREE FAIL"
            exit $status
        fi
        flash_count=$(($flash_count+1))
        info_msg "dkpg -i  $DIR/$DEVICETREE"
    fi

    if [ ! -f "$DIR/$APP" ]
    then
        info_msg "file:$DIR/$APP don't exsit"
    else
        echo taiho | sudo -S dpkg -i $DIR/$APP
        status=$?
        if [ "$status" -ne 0 ]; then
            info_msg "dkpg -i $APP FAIL"
            exit $status
        fi
        flash_count=$(($flash_count+1))
        info_msg "dkpg -i  $DIR/$APP"
    fi


    if [ ! -f "$DIR/$AI_APP" ]
    then
        info_msg "file:$DIR/$AI_APP don't exsit"
    else
        echo taiho | sudo -S dpkg -i --force-overwrite $DIR/$AI_APP
        status=$?
        if [ "$status" -ne 0 ]; then
            info_msg "dkpg -i --force-overwrite  $AI_APP FAIL"
            exit $status
        fi
        flash_count=$(($flash_count+1))
        info_msg "dkpg -i  $DIR/$AI_APP"
    fi

    if [ ! -f "$DIR/$FPGA" ]
    then
        info_msg "file:$DIR/$FPGA don't exsit"
    else
        flashcp -v /tmp/files/$FPGA /dev/mtd0
        status=$?
        if [ "$status" -ne 0 ]; then
            info_msg "flash $FPGA FAIL"
            exit $status
        fi
        flash_count=$(($flash_count+1))
        info_msg "flashcp -v /tmp/files/$BITSTREAM /dev/mtd0"
        info_msg "program fpga..."
        echo 467 > /sys/class/gpio/export
        echo out > /sys/class/gpio/gpio467/direction
        echo 0 > /sys/class/gpio/gpio467/value
        sleep 1
        echo 1 > /sys/class/gpio/gpio467/value
        info_msg "program fpga done"
    fi

    if [ "$flash_count" -eq 0 ]; then
        info_msg "flash_count is 0"
        exit 3
    fi

}

checkfile